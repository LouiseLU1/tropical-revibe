// I hate javascript

// products - uses web images for this website.
// can be replaced with local images if hosting on a server with image storage, or can be moved to a JSON file for better organization.
// can also be replaced using local images when hosting locally.
// id format: [category][number] - e.g. r1 = refill category, product 1. 
const PRODUCTS = [
  {id:'r1',name:'Shampoo Refill',cat:'refill',catLabel:'Refill Essentials',icon:'https://cdn.shopify.com/s/files/1/2160/1829/files/NL-Collection-Banners-Refill-mobile_grande.jpg?v=1587404002',price:85,desc:'Natural, sulfate-free. Bring your container!',badge:'Zero Waste'},
  {id:'r2',name:'Conditioner Refill',cat:'refill',catLabel:'Refill Essentials',icon:'https://flourishbeautylab.com/cdn/shop/products/Conditioner-Refill-Pouches.jpg?v=1685725090',price:85,desc:'Deep nourishing conditioner refill.',badge:null},
  {id:'r3',name:'Liquid Soap Refill',cat:'refill',catLabel  :'Refill Essentials',icon:'https://media.licdn.com/dms/image/sync/v2/D4E27AQF-gFpABJLw3A/articleshare-shrink_800/articleshare-shrink_800/0/1711663531830?e=2147483647&v=beta&t=Awrhe21T-Rb7owNH1M8mJlJPArROJGYwg9ed-hNd5CI',price:65,desc:'Gentle on hands, tough on germs.',badge:null},
  {id:'r4',name:'Dishwashing Liquid Refill',cat:'refill',catLabel:'Refill Essentials',icon:'https://image.made-in-china.com/2f0j00YsVkUgRBbecS/Recyclable-Mono-PE-250ml-500ml-650ml-Doypack-Spout-Pouch-Handwashing-Eco-Friendly-Dishwashing-Liquid-Refill-Pouch.webp',price:70,desc:'Cuts grease with plant-based power.',badge:null},
  {id:'r5',name:'Laundry Detergent Refill',cat:'refill',catLabel:'Refill Essentials',icon:'https://www.tenereteam.com/blogs/wp-content/uploads/2024/06/best-eco-friendly-laundry-detergents-4.webp',price:90,desc:'Effective clean, zero plastic bottle.',badge:'Best Seller'},
  {id:'r6',name:'Multi-Purpose Cleaner Refill',cat:'refill',catLabel:'Refill Essentials',icon:'https://down-my.img.susercontent.com/file/sg-11134201-22110-qfa8pgm18akv3d',price:75,desc:'All-in-one eco cleaning solution.',badge:null},
  {id:'r7',name:'Hand Sanitizer Refill',cat:'refill',catLabel:'Refill Essentials',icon:'https://images.squarespace-cdn.com/content/v1/547a3834e4b053a861c4874e/1597093767174-YZXS7FZHG70FXM1QQULT/eco-friendly-natural-hand-sanitizer',price:60,desc:'70% alcohol, skin-friendly formula.',badge:null},
  {id:'r8',name:'Body Wash Refill',cat:'refill',catLabel:'Refill Essentials',icon:'https://images.squarespace-cdn.com/content/v1/547a3834e4b053a861c4874e/26404b15-aa31-4b49-a0d4-30274f861c18/Sustainably+Chic+%7C+Sustainable+Fashion+%26+Beauty+Blog+%7C+Zero+Waste+%26+Eco+Friendly+Body+Wash+%26+Soap+%7C+Ethique.jpg?format=2500w',price:90,desc:'Luxurious lather, 100% natural scent.',badge:null},
  {id:'p1',name:'Bamboo Toothbrush',cat:'personal',catLabel:'Personal Care',icon:'https://suesen.com/wp-content/uploads/2020/03/1-146.jpg',price:95,desc:'BPA-free bristles on a compostable handle.',badge:'Eco Swap'},
  {id:'p2',name:'Safety Razor',cat:'personal',catLabel:'Personal Care',icon:'https://citizensustainable.com/wp-content/uploads/2021/12/bambaw-safety-razor.webp',price:320,desc:'Lifetime razor. Zero plastic, superior shave.',badge:'Zero Waste'},
  {id:'p3',name:'Shampoo Bar',cat:'personal',catLabel:'Personal Care',icon:'https://livnature.com/cdn/shop/collections/web-a2-Annie_Green_r1_770A0303.jpg?v=1715523061&width=2400',price:145,desc:'Lasts up to 80 washes. No bottle needed.',badge:'Best Seller'},
  {id:'p4',name:'Toothpaste Tablets',cat:'personal',catLabel:'Personal Care',icon:'https://ecologic-power.com/wp-content/uploads/2023/12/eco_friendly_toothpaste_tablets.jpg',price:175,desc:'Chew + brush. Travel-friendly.',badge:null},
  {id:'p5',name:'Natural Deodorant',cat:'personal',catLabel:'Personal Care',icon:'https://i.pinimg.com/originals/eb/a6/f9/eba6f936eed5d6824a93c9f078163943.jpg',price:185,desc:'Aluminum-free, all-day freshness.',badge:null},
  {id:'p6',name:'Reusable Cotton Pads',cat:'personal',catLabel:'Personal Care',icon:'https://m.media-amazon.com/images/I/911qbbGNarL._AC_SX679_.jpg',price:120,desc:'Set of 10 washable cotton rounds.',badge:null},
  {id:'p7',name:'Eco-Friendly Floss',cat:'personal',catLabel:'Personal Care',icon:'https://www.sustainablejungle.com/wp-content/uploads/2024/09/Image-by-Sustainable-Jungle-etee-eco-friendly-floss.jpg',price:95,desc:'Silk or corn-based, compostable packaging.',badge:null},
  {id:'p8',name:'Reusable Cotton Buds',cat:'personal',catLabel:'Personal Care',icon:'https://m.media-amazon.com/images/I/81BLRJa1xPS._SL1500_.jpg',price:110,desc:'Medical-grade silicone tips, washable.',badge:null},
  {id:'k1',name:'Beeswax Food Wraps',cat:'kitchen',catLabel:'Kitchen & Home',icon:'https://m.media-amazon.com/images/I/81hufMcHFnL._AC_SL1500_.jpg',price:195,desc:'Replace cling wrap. Reusable up to 1 year.',badge:'Eco Pick'},
  {id:'k2',name:'Stainless Steel Straws',cat:'kitchen',catLabel:'Kitchen & Home',icon:'https://i5.walmartimages.com/seo/Eco-Friendly-Stainless-Steel-Straw-Set-3-Piece-Travel-Kit-Cleaning-Brush-Home-Decor-Kitchen-Other_82b234e0-71c3-49e4-a7ff-0a503d57d6ca.b9e8d8ff0ff495a1b852ec7886941f89.jpeg?odnHeight=573&odnWidth=573&odnBg=FFFFFF',price:75,desc:'Set of 4 with cleaning brush.',badge:null},
  {id:'k3',name:'Bamboo Cutlery Set',cat:'kitchen',catLabel:'Kitchen & Home',icon:'https://tse2.mm.bing.net/th/id/OIP.erTPtlpyAoGwKlLsyDmY-QHaGV?cb=thfvnext&rs=1&pid=ImgDetMain&o=7&rm=3',price:165,desc:'Fork, knife, spoon, chopsticks + pouch.',badge:null},
  {id:'k4',name:'Reusable Glass Jars',cat:'kitchen',catLabel:'Kitchen & Home',icon:'https://thumbs.dreamstime.com/b/sustainable-zero-waste-tea-packaging-featuring-reusable-glass-jars-eco-friendly-refined-look-zero-waste-tea-packaging-367915070.jpg?w=768',price:145,desc:'Set of 3 airtight jars for pantry storage.',badge:null},
  {id:'k5',name:'Silicone Food Bags',cat:'kitchen',catLabel:'Kitchen & Home',icon:'https://m.media-amazon.com/images/I/81hijZxmGkS._AC_SL1500_.jpg',price:220,desc:'Leak-proof, freezer & microwave safe.',badge:'Best Seller'},
  {id:'k6',name:'Dish Brush',cat:'kitchen',catLabel:'Kitchen & Home',icon:'https://tse1.explicit.bing.net/th/id/OIP.ZtFxS_2O67ZGu01QiFrBEwHaHa?cb=thfvnext&rs=1&pid=ImgDetMain&o=7&rm=3',price:125,desc:'Compostable wood handle, coconut fiber bristles.',badge:null},
  {id:'k7',name:'Cloth Napkins',cat:'kitchen',catLabel:'Kitchen & Home',icon:'https://m.media-amazon.com/images/I/61YKhc2MpSL.jpg',price:95,desc:'Set of 6 cotton napkins, machine washable.',badge:null},
  {id:'k8',name:'Reusable Water Bottle',cat:'kitchen',catLabel:'Kitchen & Home',icon:'https://wellzywell.com/images/large/exploring-eco-friendly-bamboo-water-bottle.webp',price:350,desc:'Double-wall insulated stainless steel, 500ml.',badge:'Zero Waste'},
  {id:'l1',name:'Dried Mangoes',cat:'local',catLabel:'Local · Zambales',icon:'https://earthsidefarms.com/cdn/shop/files/dried_organic_mangoes_13.jpg?v=1751284645',price:95,desc:'Sun-dried Zambales mangoes. Sweet & chewy.',badge:'Local'},
  {id:'l2',name:'Pastillas',cat:'local',catLabel:'Local · Zambales',icon:'https://d22fxaf9t8d39k.cloudfront.net/c023ae5543c25d1dd98508c751894f298803f93f6f7dbbd46d395490d1c75c2640872.png',price:75,desc:'Traditional Filipino milk candy, handmade.',badge:'Local'},
  {id:'l3',name:'Calamansi Juice',cat:'local',catLabel:'Local · Zambales',icon:'https://m.media-amazon.com/images/I/71bO62XNYRL._AC_.jpg',price:85,desc:'Freshly bottled, no preservatives.',badge:'Local'},
  {id:'l4',name:'Coconut Oil',cat:'local',catLabel:'Local · Zambales',icon:'https://www.treehugger.com/thmb/_MysHzRy9jsANLDX6rjF9jOPpzU=/2121x1414/filters:fill(auto,1)/GettyImages-808164970-f75f7c744fa140dd935809fe2c01c62a.jpg',price:150,desc:'Cold-pressed, virgin coconut oil, 250ml.',badge:'Local'},
  {id:'l5',name:'Coconut Vinegar',cat:'local',catLabel:'Local · Zambales',icon:'https://www.econutrena.com/wp-content/uploads/2021/10/RYMB3696.jpg',price:90,desc:'Naturally fermented, raw & unfiltered.',badge:'Local'},
  {id:'l6',name:'Driftwood Decor',cat:'local',catLabel:'Local · Zambales',icon:'https://laughlore.com/wp-content/uploads/2024/11/image-2762.jpeg',price:280,desc:'Handcrafted driftwood art piece. Unique!',badge:'Local'},
  {id:'b1',name:'Bayong Bag',cat:'bags',catLabel:'Bags & Carriers',icon:'https://www.ourmarket.com.ph/images/blog/23/AFB06A40-D221-4DD4-8411-16FC609BDE67.jpg',price:245,desc:'Traditional Filipino woven bag. Hand-crafted.',badge:'Handmade'},
  {id:'b2',name:'Tote Bag',cat:'bags',catLabel:'Bags & Carriers',icon:'https://tse2.mm.bing.net/th/id/OIP.oY4K5b2fzOhHYdsycKagXAHaFw?cb=thfvnext&rs=1&pid=ImgDetMain&o=7&rm=3',price:175,desc:'Heavy-duty canvas tote, eco-printed.',badge:null},
];

// ok
let cart = [];
let deliveryFee = 0;
let currentStep = 1;
let currentPage = 'home';

// naviagtion
function navigate(page) {
  // hide all pages
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  // show target
  const target = document.getElementById('page-' + page);
  if (target) { target.classList.add('active'); }
  // update nav active state
  document.querySelectorAll('.nav-links a').forEach(a => a.classList.remove('active-link'));
  const map = { shop:'shop', bundles:'bundles', local:'local', why:'why', about:'about', contact:'contact' };
  if (map[page]) {
    document.querySelectorAll('.nav-links a').forEach(a => {
      if (a.getAttribute('onclick') && a.getAttribute('onclick').includes(`'${page}'`)) {
        a.classList.add('active-link');
      }
    });
  }
  currentPage = page;
  window.scrollTo(0,0);
  closeMenu();
  // re-init reveals for the new page
  setTimeout(() => {
    document.querySelectorAll('#page-' + page + ' .reveal').forEach(el => {
      revealObserver.observe(el);
    });
  }, 50);
  // render products when navigating to shop
  if (page === 'shop') renderProducts('all');
}

// render products - can be optimized by only rendering the filtered category instead of clearing and re-rendering everything, but this is simpler for now given the small product list. Can be refactored later if needed.
function renderProducts(filter='all') {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = '';
  // reset filter tabs
  document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
  const activeTab = [...document.querySelectorAll('.filter-tab')].find(t => t.getAttribute('onclick').includes(`'${filter}'`));
  if (activeTab) activeTab.classList.add('active');
  const list = filter === 'all' ? PRODUCTS : PRODUCTS.filter(p => p.cat === filter);
  list.forEach((p, i) => {
    const card = document.createElement('div');
    card.className = 'product-card reveal';
    card.innerHTML = `
      <div class="product-img">
        ${p.badge ? `<span class="product-badge">${p.badge}</span>` : ''}
        <img src="${p.icon}" alt="${p.name}" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:0;" loading="lazy" onerror="this.style.display='none'" />
      </div>
      <div class="product-body">
        <div class="product-category">${p.catLabel}</div>
        <div class="product-name">${p.name}</div>
        <div class="product-desc">${p.desc}</div>
        <div class="product-footer">
          <div class="product-price">₱${p.price}<small>per item</small></div>
          <button class="add-to-cart-btn" id="btn-${p.id}" onclick="addToCart('${p.id}')">+ Add</button>
        </div>
      </div>`;
    grid.appendChild(card);
    setTimeout(() => revealObserver.observe(card), i * 30);
  });
}

function filterProducts(cat, btn) {
  document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  renderProducts(cat);
}

// cart functions - can be optimized by using a Map for O(1) lookups instead of find/filter,
function addToCart(productId) {
  const product = PRODUCTS.find(p => p.id === productId);
  if (!product) return;
  const existing = cart.find(c => c.id === productId);
  if (existing) { existing.qty++; }
  else { cart.push({...product, qty:1}); }
  updateCartUI();
  showToast(`🌿 ${product.name} added to cart!`);
  const btn = document.getElementById('btn-' + productId);
  if (btn) {
    btn.textContent = '✓ Added';
    btn.classList.add('added');
    setTimeout(() => { btn.textContent = '+ Add'; btn.classList.remove('added'); }, 1300);
  }
}

function addBundleToCart(bundle) {
  const bundles = {
    bathroom: {id:'bundle-bathroom', name:'Bathroom Essentials Bundle', icon:'https://zuzana-eco-blog.s3.us-east-2.amazonaws.com/post-images/white-bath-background-front-view-with-cosmetics.jpg', price:520, catLabel:'Bundle Kit'},
    snacks:   {id:'bundle-snacks',   name:'Local Snacks Bundle',        icon:'https://m.media-amazon.com/images/I/71bO62XNYRL._AC_.jpg', price:380, catLabel:'Bundle Kit'},
  };
  const b = bundles[bundle];
  const existing = cart.find(c => c.id === b.id);
  if (existing) { existing.qty++; }
  else { cart.push({...b, qty:1}); }
  updateCartUI();
  showToast(`🛒 ${b.name} added to cart!`);
}

function removeFromCart(id) {
  cart = cart.filter(c => c.id !== id);
  updateCartUI();
}

function changeQty(id, delta) {
  const item = cart.find(c => c.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart = cart.filter(c => c.id !== id);
  updateCartUI();
}

function getSubtotal() { return cart.reduce((s, c) => s + c.price * c.qty, 0); }
function getTotal() { return getSubtotal() + deliveryFee; }

function updateCartUI() {
  const total = cart.reduce((s, c) => s + c.qty, 0);
  const badge = document.getElementById('cartBadge');
  badge.textContent = total;
  badge.classList.toggle('visible', total > 0);
  document.getElementById('cartCount').textContent = total > 0 ? `(${total})` : '';
  const body = document.getElementById('cartBody');
  const footer = document.getElementById('cartFooter');
  if (cart.length === 0) {
    body.innerHTML = '<div class="cart-empty"><div class="cart-empty-icon"></div><p>Your cart is empty.<br>Start adding some eco-friendly finds!</p></div>';
    footer.style.display = 'none';
  } else {
    body.innerHTML = cart.map(item => `
      <div class="cart-item">
        <div class="cart-item-icon"><img src="${item.icon}" alt="${item.name}" style="width:100%;height:100%;object-fit:cover;border-radius:6px;" /></div>
        <div class="cart-item-info">
          <div class="cart-item-name">${item.name}</div>
          <div class="cart-item-cat">${item.catLabel}</div>
          <div class="cart-item-row">
            <div class="qty-control">
              <button class="qty-btn" onclick="changeQty('${item.id}',-1)">−</button>
              <div class="qty-num">${item.qty}</div>
              <button class="qty-btn" onclick="changeQty('${item.id}',1)">+</button>
            </div>
            <div class="cart-item-price">₱${(item.price*item.qty).toLocaleString()}</div>
          </div>
          <button class="remove-item" onclick="removeFromCart('${item.id}')">Remove</button>
        </div>
      </div>`).join('');
    footer.style.display = 'block';
    document.getElementById('cartSubtotal').textContent = `₱${getSubtotal().toLocaleString()}`;
    document.getElementById('cartTotalAmt').textContent = `₱${getTotal().toLocaleString()}`;
  }
}

function openCart() {
  document.getElementById('cartOverlay').classList.add('open');
  document.getElementById('cartDrawer').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeCart() {
  document.getElementById('cartOverlay').classList.remove('open');
  document.getElementById('cartDrawer').classList.remove('open');
  document.body.style.overflow = '';
}

// checkout functions - can be further expanded with form validation, real payment integration, and order management, but this is a basic flow for demonstration purposes.
function openCheckout() {
  if (cart.length === 0) return;
  closeCart();
  currentStep = 1;
  deliveryFee = 0;
  document.getElementById('f-delivery').value = 'pickup';
  goStep(1, true);
  document.getElementById('successScreen').classList.remove('show');
  document.getElementById('checkoutGrid').style.display = '';
  document.getElementById('checkoutOverlay').classList.add('open');
  document.body.style.overflow = 'hidden';
  updateSummary();
}
function closeCheckout() {
  document.getElementById('checkoutOverlay').classList.remove('open');
  document.body.style.overflow = '';
}
function closeCheckoutOutside(e) {
  if (e.target === document.getElementById('checkoutOverlay')) closeCheckout();
}

function goStep(n, skipValidation) {
  if (!skipValidation && n === 2) {
    const name  = document.getElementById('f-name').value.trim();
    const email = document.getElementById('f-email').value.trim();
    const phone = document.getElementById('f-phone').value.trim();
    if (!name || !email || !phone) { showToast('⚠️ Please fill in all required fields.'); return; }
  }
  currentStep = n;
  for (let i = 1; i <= 3; i++) {
    document.getElementById('formStep'+i).classList.toggle('active', i===n);
    const s = document.getElementById('step'+i);
    s.classList.toggle('active', i===n);
    s.classList.toggle('done', i<n);
  }
}

function selectPayment(label) {
  document.querySelectorAll('.payment-opt').forEach(l => l.classList.remove('selected'));
  label.classList.add('selected');
}

function updateDelivery() {
  const val = document.getElementById('f-delivery').value;
  deliveryFee = val==='pickup' ? 0 : val==='local' ? 80 : 150;
  updateSummary();
}

function updateSummary() {
  const el = document.getElementById('summaryItems');
  if (!el) return;
  el.innerHTML = cart.map(item => `
    <div class="summary-item">
      <span class="summary-item-icon"><img src="${item.icon}" alt="${item.name}" style="width:100%;height:100%;object-fit:cover;border-radius:4px;" /></span>
      <div style="flex:1;min-width:0">
        <div class="summary-item-name">${item.name}</div>
        <div class="summary-item-qty">Qty: ${item.qty}</div>
      </div>
      <span class="summary-item-price">₱${(item.price*item.qty).toLocaleString()}</span>
    </div>`).join('');
  document.getElementById('sumSubtotal').textContent = `₱${getSubtotal().toLocaleString()}`;
  document.getElementById('sumDelivery').textContent = deliveryFee===0 ? 'Free / TBD' : `₱${deliveryFee}`;
  document.getElementById('sumTotal').textContent = `₱${getTotal().toLocaleString()}`;
}

function placeOrder() {
  const orderId = 'TRV-' + Date.now().toString().slice(-7).toUpperCase();
  document.getElementById('orderIdEl').textContent = `Order Reference: ${orderId}`;
  document.getElementById('checkoutGrid').style.display = 'none';
  document.getElementById('successScreen').classList.add('show');
  cart = []; deliveryFee = 0;
  updateCartUI();
}

function finishOrder() {
  closeCheckout();
  navigate('shop');
  showToast('🌿 Thank you for shopping at Tropical ReVibe!');
}

// utility function for setting card background from file input - can be used for user profile picture or custom product images if needed.
function setCardBg(input, id) {
  const file = input.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    const cardImg = document.getElementById(id);
    cardImg.style.backgroundImage = `url('${e.target.result}')`;
    cardImg.style.backgroundSize = 'cover';
    cardImg.style.backgroundPosition = 'center';
    cardImg.classList.add('has-image');
  };
  reader.readAsDataURL(file);
}

// simple notification system for user feedback like adding to cart, etc..
let toastTimer;
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2500);
}

// navbar
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => navbar.classList.toggle('scrolled', window.scrollY > 30));
function toggleMenu() { document.getElementById('navLinks').classList.toggle('open'); }
function closeMenu() { document.getElementById('navLinks').classList.remove('open'); }

// leaf animation
const leafContainer = document.getElementById('leaves');
const leafPaths = [
  'M10,30 Q25,0 40,15 Q55,30 40,50 Q25,65 10,50 Q-5,35 10,30Z',
  'M5,20 Q20,5 35,20 Q50,35 35,55 Q20,70 5,55 Q-10,40 5,20Z',
  'M15,10 Q35,0 50,20 Q65,40 50,60 Q35,75 15,60 Q0,45 15,10Z'
];
function spawnLeaf() {
  if (currentPage !== 'home') return;
  const el = document.createElement('div');
  el.className = 'leaf';
  const size=20+Math.random()*40, dur=8+Math.random()*12, delay=Math.random()*5;
  el.style.cssText=`width:${size}px;height:${size}px;left:${Math.random()*100}vw;bottom:-${size}px;animation:leafFloat ${dur}s ${delay}s ease-in forwards;`;
  const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
  svg.setAttribute('viewBox','0 0 60 80');
  const path=document.createElementNS('http://www.w3.org/2000/svg','path');
  path.setAttribute('d',leafPaths[Math.floor(Math.random()*leafPaths.length)]);
  path.setAttribute('fill',`rgba(0,196,114,${0.3+Math.random()*0.4})`);
  svg.appendChild(path); el.appendChild(svg); leafContainer.appendChild(el);
  setTimeout(()=>el.remove(),(dur+delay)*1000);
}
setInterval(spawnLeaf, 2200);
spawnLeaf(); spawnLeaf();

// scroll animation
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((e,i) => {
    if (e.isIntersecting) {
      setTimeout(()=>e.target.classList.add('visible'), i*60);
      revealObserver.unobserve(e.target);
    }
  });
}, {threshold:0.08});
document.querySelectorAll('#page-home .reveal').forEach(el=>revealObserver.observe(el));

// closing cart and checkout using escape key
document.addEventListener('keydown', e => { if (e.key==='Escape'){closeCart();closeCheckout();} });
